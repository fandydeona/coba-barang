<footer class="pc-footer">
    <div class="footer-wrapper container-fluid">
        <div class="row">
            <div class="col-sm-6 my-1">
                <p class="m-0">Apps Stok Barang &#9829; crafted by <a href="#">Lita A. Ndoloe</a></p>
            </div>
        </div>
    </div>
</footer>