<script src="assets/popper.min.js"></script>
<script src="assets/simplebar.min.js"></script>
<script src="assets/bootstrap.min.js"></script>
<script src="assets/custom-font.js"></script>
<script src="assets/pcoded.js"></script>
<scrip src="assets/feather.min.js"></script>
<script src="assets/simple-datatables.js"></script>
    <script>
        const dataTable = new simpleDatatables.DataTable('#pc-dt-simple', {
            sortable: false,
            perPage: 5
        });
    </script>
    <script>
        layout_change('light');
    </script>
    <script>
        font_change("Roboto");
    </script>
    <script>
        change_box_container('false');
    </script>
    <script>
        layout_caption_change('true');
    </script>
    <script>
        layout_rtl_change('false');
    </script>
    <script>
        preset_change("preset-1");
    </script>
    </body>

    </html>