<?php
$host       = 'localhost';
$user       = 'root';
$pass       = '';
$dbname     = 'stok_barang';

$conn = mysqli_connect($host, $user, $pass, $dbname);
