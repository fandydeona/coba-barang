<?php
require_once('../helper/koneksi-db.php');

// tambah barang
if (isset($_POST['addbarang'])) {

    $nama_barang = $_POST['nama_barang'];
    $stok = $_POST['stok'];
    $deskripsi = $_POST['deskripsi'];

    $queryInsert = "INSERT INTO barang (nama_barang, stok, deskripsi) 
                    VALUES (?, ?, ?)";
    $stmtInsert = $conn->prepare($queryInsert);
    $stmtInsert->bind_param("sss", $nama_barang, $stok, $deskripsi);

    if ($stmtInsert->execute()) {
        header("Location: ../barang.php?process=success");
        exit();
    }

    $stmtInsert->close();
}
// akhir tambah

// ubah barang
elseif (isset($_POST['updatebarang'])) {

    $id_barang = $_POST['id_barang'];
    $nama_barang = $_POST['nama_barang'];
    $stok = $_POST['stok'];
    $deskripsi = $_POST['deskripsi'];

    $queryUpdate = "UPDATE barang SET nama_barang = ?, stok = ?, deskripsi = ? WHERE id_barang = ?";
    $stmtUpdate = $conn->prepare($queryUpdate);

    $stmtUpdate->bind_param("sisi", $nama_barang, $stok, $deskripsi, $id_barang);

    if ($stmtUpdate->execute()) {
        header("Location: ../barang.php?process=successup");
        exit();
    } else {
        die('Error executing statement: ' . $stmtUpdate->error);
    }

    $stmtUpdate->close();
}
// akhir ubah

// hapus barang
elseif (isset($_POST['deletebarang'])) {

    $id_barang = $_POST['id_barang'];

    $queryDelete = "DELETE FROM barang WHERE id_barang = ?";
    $stmtdel = $conn->prepare($queryDelete);

    $stmtdel->bind_param("s", $id_barang);

    if ($stmtdel->execute()) {
        header("Location: ../barang.php?process=successdel");
        exit();
    } else {
        die('Error executing statement: ' . $stmtdel->error);
    }

    $stmtdel->close();
}
// akhir hapus